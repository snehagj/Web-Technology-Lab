<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Date Functions</title>
</head>
<body>
    <?php
        echo "Current Date: " . date("d/m/Y") . "<br>";
        echo "Day of the Week: " . date("l") . "<br>";
        echo "Current Year: " . date("Y") . "<br>";
        date_default_timezone_set("Asia/Kolkata");
        echo "The time is " . date("H:i:sa");
    ?>
</body>
</html>