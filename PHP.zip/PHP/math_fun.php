<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Math Functions</title>
</head>
<body>
    <?php
        $num = 25;
        echo "Number: $num<br>";
        echo "Square Root: " . sqrt($num) . "<br>";

    ?>
</body>
</html>