<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>String Functions</title>
</head>
<body>
    <?php
        $str = "Hello, World!";
        echo "Original String: $str<br>";
        echo "String Length: " . strlen($str) . "<br>";
        echo "Reversed String: " . strrev($str) . "<br>";
        echo "Uppercase String: " . strtoupper($str) . "<br>";
        echo "Lowercase String: " . strtolower($str) . "<br>";
    ?>
</body>
</html>