<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array Functions</title>
</head>
<body>
    <?php
        $arr = array(10, 20, 30, 40, 50);

        // 1. Display array elements
        echo "1. Array Elements: " . implode(", ", $arr) . "<br>";

        // 2. Get array length
        echo "2. Array Length: " . count($arr) . "<br>";

        // 3. Sum of array elements
        echo "3. Sum of Elements: " . array_sum($arr) . "<br>";

        // 4. Reverse the array
        echo "4. Reversed Array: " . implode(", ", array_reverse($arr)) . "<br>";

        // 5. Maximum value in the array
        echo "5. Maximum Value: " . max($arr) . "<br>";

        // 6. Minimum value in the array
        echo "6. Minimum Value: " . min($arr) . "<br>";

        // 7. Sort the array
        sort($arr);
        echo "7. Sorted Array: " . implode(", ", $arr) . "<br>";

        // 8. Reverse sort the array
        rsort($arr);
        echo "8. Reverse Sorted Array: " . implode(", ", $arr) . "<br>";

        // 9. Merge two arrays
        $arr2 = array(60, 70, 80);
        $merged = array_merge($arr, $arr2);
        echo "9. Merged Array: " . implode(", ", $merged) . "<br>";

        // 10. Remove duplicate values
        $unique = array_unique(array(10, 20, 20, 30, 40, 40, 50));
        echo "10. Unique Elements: " . implode(", ", $unique) . "<br>";

        // 11. Chunk the array
        $chunked = array_chunk($arr, 2);
        echo "11. Chunked Array: ";
        foreach ($chunked as $chunk) {
            echo "[" . implode(", ", $chunk) . "] ";
        }
        echo "<br>";

        // 12. Flip keys and values
        $flipped = array_flip(array("a" => 10, "b" => 20, "c" => 30));
        echo "12. Flipped Array: ";
        foreach ($flipped as $key => $value) {
            echo "$key => $value, ";
        }
        echo "<br>";

        // 13. Get array keys
        $keys = array_keys($arr);
        echo "13. Array Keys: " . implode(", ", $keys) . "<br>";

        // 14. Get array values
        $values = array_values($arr);
        echo "14. Array Values: " . implode(", ", $values) . "<br>";

        // 15. Filter array values
        $filtered = array_filter($arr, function($value) {
            return $value > 20;
        });
        echo "15. Filtered Array (values > 20): " . implode(", ", $filtered) . "<br>";

        // 16. Map array values
        $mapped = array_map(function($value) {
            return $value * 2;
        }, $arr);
        echo "16. Mapped Array (values * 2): " . implode(", ", $mapped) . "<br>";

        // 17. Reduce array to a single value
        $reduced = array_reduce($arr, function($carry, $item) {
            return $carry + $item;
        }, 0);
        echo "17. Reduced Array (sum): " . $reduced . "<br>";
    ?>
</body>
</html>