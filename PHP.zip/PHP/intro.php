<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Introduction</title>
</head>
<body>
    <?php
        $name = "Sneha Jadhav";
        $college = "D. Y. Patil College of Engineering & Technology, Kolhapur";
        $branch = "Computer Science and Engineering";
        $course = "B-Tech. Computer Science and Engineering";
        $year = 2026;
        $sem = 6;
        $rollNo =49;
        $subject = "Web Technology";
        

        echo "Name: " . $name . "<br>";
        echo "College: " . $college . "<br>";
        echo "Branch: " . $branch . "<br>";
        echo "Course: " . $course . "<br>";
        echo "Year: " . $year . "<br>";
        echo "Semester: " . $sem . "<br>";
        echo "Roll No: " . $rollNo . "<br>";
        echo "Subject: " . $subject . "<br>";
    ?>
</body>
</html>