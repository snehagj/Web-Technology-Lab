<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculations</title>
</head>
<body>
    <?php
        $num1 = 10;
        $num2 = 20;
        $num3 = 5;

        $sum = $num1 + $num2 + $num3;

        if ($num1 > $num2 && $num1 > $num3) {
            $greatest = $num1;
        } 
        elseif ($num2 > $num1 && $num2 > $num3) {
            $greatest = $num2;
        } 
        else {
            $greatest = $num3;
        }

        if ($num1 < $num2 && $num1 < $num3) {
            $smallest = $num1;
        } 
        elseif ($num2 < $num1 && $num2 < $num3) {
            $smallest = $num2;
        } 
        else {
            $smallest = $num3;
        }

        $factorial1 = 1;
        for ($i = 1; $i <= $num1; $i++) {
            $factorial1 *= $i;
        }

        $factorial2 = 1;
        for ($i = 1; $i <= $num2; $i++) {
            $factorial2 *= $i;
        }

        $factorial3 = 1;
        for ($i = 1; $i <= $num3; $i++) {
            $factorial3 *= $i;
        }


        echo "Numbers: $num1, $num2, $num3<br>";
        echo "Sum: $sum<br>";
        echo "Greatest Number: $greatest<br>";
        echo "Smallest Number: $smallest<br>";
        echo "Factorial of $num1: $factorial1<br>";
        echo "Factorial of $num2: $factorial2<br>";
        echo "Factorial of $num3: $factorial3<br>";

    ?>
</body>
</html>